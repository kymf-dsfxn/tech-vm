/*++Copyright (c) 2015 SAP AG or an SAP affiliate company.  All rights reserved.
**This copyright block is auto-generated.  Use copyright_cpp_style.sh to update it.
--*/

#ifndef SYBSQLTYPES_H
#define SYBSQLTYPES_H

#ifndef __SQLTYPES
#include "sqltypes.h"
#endif

#ifndef SQL_API
#ifdef WIN32
#define SQL_API    __stdcall
#else
#define SQL_API
#endif
#endif

#ifdef __cplusplus
extern "C" {             /* Assume C declarations for C++   */
#endif  /* __cplusplus */

    /*
    ODBC SPECIFC DEFINITIONS , THESE SHOULD ALREADY BE DEFINED IN
    STANDARD ODBC INCLUDE FILES SQLTYPES.H,SQLEXT.H, SQL.H
    IF NOT DEFINED IN THE ODBC HEADER FILES, THESE VALUES WILL BE
    DEFINED HERE  TAKEN FROM THE ODBC API REFERENCE
    */

    /*
    NOTE ANY DEFINITIONS USED HERE HAVE TO BE APPROVED BY THE OPEN GROUP
    https://www.opengroup.org/projects/drda/uploads/40/9360/wpaper.htm
    */
#ifndef SQL_DRIVER_SQL_TYPE_BASE
#define SQL_DRIVER_SQL_TYPE_BASE    0x4000
#endif

#ifndef SQL_DRIVER_CONNECT_ATTR_BASE
#define SQL_DRIVER_CONNECT_ATTR_BASE 0x00004000
#endif

#ifndef SQL_DRIVER_STATEMENT_ATTR_BASE
#define SQL_DRIVER_STATEMENT_ATTR_BASE 0x00004000
#endif

    /*    LOCATOR DEFINITIONS */
    /*locator SQL TYPE*/
#define SQL_TEXT_LOCATOR        SQL_DRIVER_SQL_TYPE_BASE +10
#define SQL_UNITEXT_LOCATOR     SQL_DRIVER_SQL_TYPE_BASE +11
#define SQL_IMAGE_LOCATOR       SQL_DRIVER_SQL_TYPE_BASE +13



#ifndef SQL_DRIVER_STATEMENT_ATTR_BASE
#define SQL_DRIVER_STATEMENT_ATTR_BASE 0x00004000
#endif

#ifndef SQL_DRIVER_C_DATATYPES_BASE
#define SQL_DRIVER_C_DATATYPES_BASE 0x4000
#endif

#ifndef SQL_DRIVER_C_DATATYPES_END
#define SQL_DRIVER_C_DATATYPES_END 0x7FFF
#endif



    /*locator C TYPE */
#define SQL_C_TEXT_LOCATOR        SQL_DRIVER_C_DATATYPES_BASE + 1
#define SQL_C_UNITEXT_LOCATOR      SQL_DRIVER_C_DATATYPES_BASE + 2
#define SQL_C_IMAGE_LOCATOR       SQL_DRIVER_C_DATATYPES_BASE + 3

    /*Packed BCD C Type*/
#define SQL_C_PACKEDBCD            SQL_DRIVER_C_DATATYPES_BASE + 4
#define SQL_MAX_PACKEDBCD_DIGITS    100

    /*value for the Locator size */
#define SQL_LOCATOR_SIZE        24

    /* attribute to control batch without parameter arrays */
#define SQL_ATTR_BATCH_PARAMS        SQL_DRIVER_CONNECT_ATTR_BASE + 10

    /*attribute to control set send locator on/off*/
#define SQL_ATTR_LOBLOCATOR            SQL_DRIVER_CONNECT_ATTR_BASE + 11

    /*attribute to get a verbose version string*/
#define SQL_DRIVER_VERBOSE_VER        SQL_DRIVER_CONNECT_ATTR_BASE + 12

    /*attribute to manipulate instrumentation*/
#define SQL_ATTR_INSTRUMENTATION    SQL_DRIVER_CONNECT_ATTR_BASE + 13
#define SQL_ATTR_INSTRUMENTATION_LOG SQL_DRIVER_CONNECT_ATTR_BASE + 14

    /* attribute to pause/resume protocol capture */
#define SQL_ATTR_PROTOCOL_CAPTURE SQL_DRIVER_CONNECT_ATTR_BASE + 15

    /* attributes to configure odbc tracing */
#define SQL_OPT_TRACEFORMAT SQL_DRIVER_CONNECT_ATTR_BASE + 16
#define SQL_OPT_TRACECALLBACK SQL_DRIVER_CONNECT_ATTR_BASE + 17

    /* attribute to configure bulk
     * 0 - disabled
     * 1 - array insert
     * 2 - fast bulk
     * 3 - fast logged bulk
     * */
#define SQL_ATTR_ENABLE_BULK_LOAD SQL_DRIVER_CONNECT_ATTR_BASE + 18

    /* attribute to configure batch
     * 0 - disabled
     * 1 - enabled
     * 2 - enabled, use bulk for insert - this option requires SQL_ATTR_ENABLE_BULK_LOAD > 0
     * */
#define SQL_ATTR_HOMOGENEOUS_BATCH SQL_DRIVER_CONNECT_ATTR_BASE + 19

#define SQL_ATTR_CLIENT_NAME  SQL_DRIVER_CONNECT_ATTR_BASE + 20
#define SQL_ATTR_CLIENT_HOST_NAME SQL_DRIVER_CONNECT_ATTR_BASE + 21
#define SQL_ATTR_CLIENT_APPL_NAME SQL_DRIVER_CONNECT_ATTR_BASE + 22


#define SQL_LOBLOCATOR_ON                1
#define SQL_LOBLOCATOR_OFF               0

#define SQL_ATTR_LOBLOCATOR_FETCHSIZE    SQL_DRIVER_STATEMENT_ATTR_BASE + 10

    /* values for SQL_ATTR_BATCH_PARAMS */
#define SQL_BATCH_DISABLED      0
#define SQL_BATCH_ENABLED       1
#define SQL_BATCH_LAST_NO_DATA  (-1)
#define SQL_BATCH_LAST_DATA     (-2)
#define SQL_BATCH_CANCEL        (-3)

    /* values for SQL_ATTR_PROTOCOL_CAPTURE */
#define SQL_CAPTURE_PAUSE 0
#define SQL_CAPTURE_RESUME 1

    /* SQLRETURN for SQLExecute and SQLExecDirect while in a batch */
#define SQL_BATCH_EXECUTING        200

    /* Values for SQL_ATTR_INSTRUMENTATION */
#define SQL_INSTRUMENTATION_ENABLE      0
#define SQL_INSTRUMENTATION_DISABLE     1
#define SQL_INSTRUMENTATION_CLEAR       3
#define SQL_INSTRUMENTATION_CLEAR_ALL   4
#define SQL_INSTRUMENTATION_FINE        5
#define SQL_INSTRUMENTATION_LOG         6

    /* A packed bcd value is simply an array of bytes. The precision defines
     * how many bytes are used. To declare a variable large enough to hold
     * the largest supported value use:
     * BYTE value[SQL_MAX_PACKEDBCD_DIGITS];
     */
    typedef BYTE* SQL_PACKEDBCD;
    SQLRETURN  SQL_API SQLBindColumnDA(
        SQLHSTMT StatementHandle,
        SQLSMALLINT* TargetTypes,
        SQLSMALLINT* Precisions,
        SQLSMALLINT* Scales,
        SQLPOINTER* TargetValuePtrs,
        SQLLEN* BufferLengths,
        SQLLEN** StrLens_or_Inds,
        SQLUSMALLINT Columns);

    SQLRETURN  SQL_API SQLBindParameterDA(
        SQLHSTMT StatementHandle,
        SQLSMALLINT* InputOutputTypes,
        SQLSMALLINT* ValueTypes,
        SQLSMALLINT* ParameterTypes,
        SQLULEN* ColumnSizes,
        SQLSMALLINT* DecimalDigits,
        SQLPOINTER* ParameterValuePtrs,
        SQLLEN* BufferLengths,
        SQLLEN** StrLens_or_IndPtrs,
        SQLUSMALLINT Parameters);


    /* HADR List */

    /* Retrieve the current HADR list map generation */
#define SQL_ATTR_DR_LIST_GENERATION     SQL_DRIVER_CONNECT_ATTR_BASE + 23

    /* Retrieve the current HADR list map - data will be
       returned using SQLHADRDataSourceList structure. */
#define SQL_ATTR_DR_LIST                SQL_DRIVER_CONNECT_ATTR_BASE + 24

    /* Used to set the callback function to be called when the HADR list
       is updated. Signature should match HADRListAllocCallback. This
       callback is used to inform the application that an update is available
       and the amount of space needed to hold it.*/
#define SQL_ATTR_HADR_LIST_CALLBACK     SQL_DRIVER_CONNECT_ATTR_BASE + 25

    typedef void(*SQLHADRListAllocCallback)(HDBC conn, SQLINTEGER generation_number, SQLLEN size_needed);

    struct SQLHADRDataSource
    {
        // The name of the data source. Regardless of the setting of
        // SQL_OUTPUT_NTS, this name is null terminated.
        SQLWCHAR* data_source_name;
        SQLLEN data_source_name_length;

        // The number of address for this data source. Each address refers
        // to the same data source (server)
        SQLLEN number_of_addresses;

        // An array of size number_of_addresses containing pointers to each
        // address in the array. The addresses are in the same format as
        // addresses in the interfaces file. Regardless of the setting of
        // SQL_OUTPUT_NTS, the addresses are null terminated.
        SQLWCHAR** address_list;
        SQLLEN* address_list_lengths;

        // The number of HA companions available for this data source.
        SQLLEN number_of_ha_companions;

        // An array of size number_of_ha_companions containing pointers to
        // the SQLHADRDataSource for each of the HA companion servers.
        SQLHADRDataSource** ha_companion_list;

        // This SQLINTEGER is treated as a set of flags for the data source.
        // Currently, the only flag defined is SQL_DR_READONLY.
        SQLINTEGER flags;
    };

    struct SQLHADRDataSourceList
    {
        // The generation number of this list
        SQLLEN generation;

        // The group name of this list. Regardless of the setting of
        // SQL_OUTPUT_NTS, this name is null terminated.
        SQLWCHAR* group_name;
        SQLLEN group_name_length;

        // The number of data sources in the data source list.
        SQLLEN number_of_data_sources;

        // An array of size number_of_data_sources containing pointers to
        // each SQLHADRDataSource in the list.
        SQLHADRDataSource** data_source_list;
    };

    /* DR Info */

    /* Retrieves the most recently send info message */
#define SQL_ATTR_DR_INFO_MSG        SQL_DRIVER_CONNECT_ATTR_BASE + 26

    /* Retrieves the timeout for deactivation. This timeout is the specific time
       at which the timeout will occur. */
#define SQL_ATTR_DR_DEACTIVATION_TIMEOUT        SQL_DRIVER_CONNECT_ATTR_BASE + 27

    /* Used to set the callback function to be called when the driver
       receives a new info message. It should be of tye type
       SQLHADRInfoCallback */
#define SQL_ATTR_DR_INFO_CALLBACK   SQL_DRIVER_CONNECT_ATTR_BASE + 28

    typedef void(*SQLHADRInfoCallback)(HDBC conn, SQLINTEGER new_state, SQL_TIMESTAMP_STRUCT timeout);

    /* Used to set the callback function to be called when the driver
       receives a failover message from the server. It should be of
       the type SQLHADRFailoverCallback. */
#define SQL_ATTR_HADR_FAILOVER_CALLBACK   SQL_DRIVER_CONNECT_ATTR_BASE + 29

    typedef void(*SQLHADRFailoverCallback)(HDBC conn);

#define SQL_ATTR_ODBC_TRACE_LEVEL SQL_DRIVER_CONNECT_ATTR_BASE + 30

    /* Information message values
    */
#define SQL_DR_ACTIVE 0
#define SQL_DR_CONNECTION_LOST 1
#define SQL_DR_FAILOVER 2376
#define SQL_DR_DEACTIVATING 2377
#define SQL_DR_DEACTIVATION_CANCELED 2378
#define SQL_DR_DEACTIVATED 2379
#define SQL_DR_REACTIVATED 2380

#define SQL_DIAG_ASE_BASE (-1250)
#define SQL_DIAG_ASE_LINE_NUMBER (SQL_DIAG_ASE_BASE-1)
#define SQL_DIAG_ASE_MESSAGE_SEVERITY (SQL_DIAG_ASE_BASE-2)
#define SQL_DIAG_ASE_MESSAGE_STATE (SQL_DIAG_ASE_BASE-3)
#define SQL_DIAG_ASE_STORED_PROCEDURE_NAME (SQL_DIAG_ASE_BASE-4)
#define SQL_DIAG_ASE_SERVER_NAME (SQL_DIAG_ASE_BASE-5)

#define SQL_ATTR_CREATE_THREAD_FOR_CANCEL SQL_DRIVER_CONNECT_ATTR_BASE + 31
#define SQL_ATTR_RETURN_PREPARE_ERRORS SQL_DRIVER_CONNECT_ATTR_BASE + 32

    /*
    SnapShot Isolation support
    */
#define SQL_ATTR_TXN_ISOLATION_MODE SQL_DRIVER_CONNECT_ATTR_BASE + 33

#define SQL_TXN_ISOLATION_MODE_DEFAULT              0
#define SQL_TXN_ISOLATION_MODE_SNAPSHOT             1
#define SQL_TXN_ISOLATION_MODE_READONLY_SNAPSHOT    2

    /*
    Define new isolation levels
    */

#define SQL_TXN_ASE_STATEMENT_SNAPSHOT                          0x0000000BL
#define SQL_TRANSACTION_ASE_STATEMENT_SNAPSHOT                  SQL_TXN_ASE_STATEMENT_SNAPSHOT

#define SQL_TXN_ASE_TRANSACTION_SNAPSHOT                        0x0000000CL
#define SQL_TRANSACTION_ASE_TRANSACTION_SNAPSHOT                SQL_TXN_ASE_TRANSACTION_SNAPSHOT

#define SQL_TXN_ASE_READONLY_STATEMENT_SNAPSHOT                 0x0000000DL
#define SQL_TRANSACTION_ASE_READONLY_STATEMENT_SNAPSHOT         SQL_TXN_ASE_READONLY_STATEMENT_SNAPSHOT

    /*attribute to get the build timestamp*/
#define SQL_DRIVER_BUILD_TIMESTAMP SQL_DRIVER_CONNECT_ATTR_BASE + 34

    /*attribute to get the commit timestamp*/
#define SQL_DRIVER_SOURCE_VERSION_TIMESTAMP SQL_DRIVER_CONNECT_ATTR_BASE + 35

    /*attribute to get the commit SHA1 HASH*/
#define SQL_DRIVER_SOURCE_VERSION_ID SQL_DRIVER_CONNECT_ATTR_BASE + 36

    /* attributes for command encryption
     * SQL_TRUE - enabled
     * SQL_FALSE - disabled
     * */
#define SQL_ATTR_COMMAND_ENCRYPTION      SQL_DRIVER_CONNECT_ATTR_BASE + 37

// Added to test ansinull
#define SQL_ATTR_ANSINULL      SQL_DRIVER_CONNECT_ATTR_BASE + 38
#define SQL_ANSINULL_ON                1
#define SQL_ANSINULL_OFF               0

// KeepAlive support
#define SQL_ATTR_TCP_KEEPALIVE_CNT SQL_DRIVER_CONNECT_ATTR_BASE + 39
#define SQL_ATTR_TCP_KEEPALIVE_IDLE SQL_DRIVER_CONNECT_ATTR_BASE + 40
#define SQL_ATTR_TCP_KEEPALIVE_INTVL SQL_DRIVER_CONNECT_ATTR_BASE + 41

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif //SYBSQLTYPES_H
